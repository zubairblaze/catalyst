<?php
// The Catalyst — contact form handler for cPanel/Apache (PHP).
// Receives the JSON posted by the site's contact form and emails info@.
header('Content-Type: application/json');

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

$raw = file_get_contents('php://input');
$d = json_decode($raw, true);
if (!is_array($d)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid request']);
    exit;
}

// Honeypot — bots fill this; silently accept.
if (!empty($d['company'])) {
    echo json_encode(['ok' => true, 'delivered' => false]);
    exit;
}

$name    = trim($d['name'] ?? '');
$email   = trim($d['email'] ?? '');
$message = trim($d['message'] ?? '');
$phone   = trim($d['phone'] ?? '');
$service = trim($d['service'] ?? '');

if ($name === '' || $email === '' || $message === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Please fill in your name, email and message.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Please enter a valid email address.']);
    exit;
}

// ---- Where enquiries are sent ----
$to = 'info@thecatalystfze.com';

$subject = 'New enquiry from ' . $name . ($service !== '' ? ' — ' . $service : '');

$body  = "Name: $name\n";
$body .= "Email: $email\n";
$body .= 'Phone: ' . ($phone !== '' ? $phone : '—') . "\n";
$body .= 'Service: ' . ($service !== '' ? $service : '—') . "\n\n";
$body .= "Message:\n$message\n";

// Use a From address on your own domain for best deliverability.
$from = 'info@thecatalystfze.com';
$headers  = 'From: The Catalyst Website <' . $from . ">\r\n";
$headers .= 'Reply-To: ' . $name . ' <' . $email . ">\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

$sent = @mail($to, $subject, $body, $headers);

echo json_encode(
    $sent
        ? ['ok' => true, 'delivered' => true]
        : ['ok' => true, 'delivered' => false, 'reason' => 'mail-failed']
);
